/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Vendingmachine
{
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		int n = sc.nextInt();
		
		sc.nextLine();
		
		String Prices1 = sc.nextLine();
		String[ ] parts = Prices1.split(" ");
		int [ ] prices = new int[n];
		for(int i=0;i<n;i++){
		    prices[i] = Integer.parseInt(parts[i]);
		}
		int money = sc.nextInt();
		
		int item = sc.nextInt();
		
		if(item>0 && item<=n){
		    int sprice = prices[item];
		    if(money >= sprice){
		        System.out.print("item dispence," + "yoour change = " + (money-sprice) );
		    }
		    else{
		        System.out.print("Sorry,Insuffisient funds");
		    }
		}
		else{
		     System.out.print("enter item number between n");
		 }
		sc.close();
	}
}
